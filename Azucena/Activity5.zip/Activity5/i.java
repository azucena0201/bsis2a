package Activity5;

public class i {

  public static void main(String[] args) {
  
   {
  for (int i=0; i<4; i++)
  {
  for (int j=0; j<9; j++)
  {
    System.out.print("*");
  }
  System.out.println("*");
  }
}
  }
  }
