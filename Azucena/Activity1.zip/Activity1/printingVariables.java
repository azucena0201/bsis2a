package Activity1;

public class printingVariables {

  public static void main(String[] args) {
  
  int number=10;
  char letter='a';
  boolean result=true;
  String str="hello";
  
  System.out.println("number="+number);
  System.out.println("letter="+letter);
  System.out.println("result="+result);
  System.out.println("str="+str);
   
  }
}
