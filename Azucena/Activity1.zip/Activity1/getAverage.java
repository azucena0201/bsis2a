package Activity1;
import java.util.Scanner;

public class getAverage {
public static void main(String [] args){
  Scanner average=new Scanner(System.in);
  int num1=10;
  System.out.println("number 1="+num1);
  
  int num2=20;
  System.out.println("number 2="+num2);
  
  int num3=45;
  System.out.println("number 3="+num3);
  
  System.out.println("average="+(num1+num2+num3)/3);
}

}
